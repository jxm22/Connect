class UserModel {
  String name;
  String userUid;
  String emailId;
  String avatarUrl;
}