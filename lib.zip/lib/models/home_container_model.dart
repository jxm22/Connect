class HomeContainerModel {
  String userNameGlobal, userPicUrlGlobal, chatRoomIdGlobal, userEmailGlobal;
  bool isChatSelected = false;
  bool isSearching = false;
  Stream messagesStream;
}